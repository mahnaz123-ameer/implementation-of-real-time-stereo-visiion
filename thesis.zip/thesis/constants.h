#ifndef CONSTANTS_H
#define CONSTANTS_H

const int IMAGE_WIDTH = 320;
const int IMAGE_HEIGHT = 240;
const int MAX_DISPARITY = 60;

#endif // CONSTANTS_H
