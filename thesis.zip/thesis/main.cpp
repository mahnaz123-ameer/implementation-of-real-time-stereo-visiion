#include "camera_capture.h"

int main() {
    capture();
    return 0;
}
